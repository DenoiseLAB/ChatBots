VideoChatScheduled
==================

.. autoclass:: telegram.VideoChatScheduled
    :members:
    :show-inheritance:
