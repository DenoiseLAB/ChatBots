PassportElementErrorFile
========================

.. autoclass:: telegram.PassportElementErrorFile
    :members:
    :show-inheritance:
