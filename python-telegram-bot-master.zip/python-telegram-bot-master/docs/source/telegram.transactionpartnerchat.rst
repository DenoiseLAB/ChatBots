TransactionPartnerChat
======================

.. autoclass:: telegram.TransactionPartnerChat
    :members:
    :show-inheritance:
    :inherited-members: TransactionPartner
