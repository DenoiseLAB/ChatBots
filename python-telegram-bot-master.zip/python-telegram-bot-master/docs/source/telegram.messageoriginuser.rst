MessageOriginUser
=================

.. autoclass:: telegram.MessageOriginUser
    :members:
    :show-inheritance:
