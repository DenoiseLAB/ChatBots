GeneralForumTopicUnhidden
=========================

.. autoclass:: telegram.GeneralForumTopicUnhidden
    :members:
    :show-inheritance:
