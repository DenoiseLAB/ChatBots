BaseRequest
===========

.. autoclass:: telegram.request.BaseRequest
    :members:
    :show-inheritance: