InlineQueryResult
=================

.. autoclass:: telegram.InlineQueryResult
    :members:
    :show-inheritance:
