BackgroundTypeFill
==================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundTypeFill
    :members:
    :show-inheritance: