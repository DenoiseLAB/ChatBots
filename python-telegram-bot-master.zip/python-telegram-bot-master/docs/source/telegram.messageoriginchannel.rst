MessageOriginChannel
====================

.. autoclass:: telegram.MessageOriginChannel
    :members:
    :show-inheritance:
