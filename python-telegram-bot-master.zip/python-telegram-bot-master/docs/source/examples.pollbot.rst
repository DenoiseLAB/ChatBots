``pollbot.py``
==============

.. literalinclude:: ../../examples/pollbot.py
   :language: python
   :linenos:
    