``inlinekeyboard2.py``
======================

.. literalinclude:: ../../examples/inlinekeyboard2.py
   :language: python
   :linenos:
    