TransactionPartnerTelegramApi
=============================

.. autoclass:: telegram.TransactionPartnerTelegramApi
    :members:
    :show-inheritance:
    :inherited-members: TransactionPartner
