ReactionTypeCustomEmoji
=======================

.. autoclass:: telegram.ReactionTypeCustomEmoji
    :members:
    :show-inheritance:
