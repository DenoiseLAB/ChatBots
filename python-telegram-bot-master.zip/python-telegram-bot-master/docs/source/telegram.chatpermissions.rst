ChatPermissions
===============

.. autoclass:: telegram.ChatPermissions
    :members:
    :show-inheritance:
