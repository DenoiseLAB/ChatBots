StarTransactions
================

.. autoclass:: telegram.StarTransactions
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject

