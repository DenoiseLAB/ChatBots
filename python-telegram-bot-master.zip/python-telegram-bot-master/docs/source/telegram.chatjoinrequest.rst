ChatJoinRequest
===============

.. autoclass:: telegram.ChatJoinRequest
    :members:
    :show-inheritance:
