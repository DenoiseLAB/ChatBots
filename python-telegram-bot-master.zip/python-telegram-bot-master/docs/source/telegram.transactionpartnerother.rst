TransactionPartnerOther
=======================

.. autoclass:: telegram.TransactionPartnerOther
    :members:
    :show-inheritance:
    :inherited-members: TransactionPartner
