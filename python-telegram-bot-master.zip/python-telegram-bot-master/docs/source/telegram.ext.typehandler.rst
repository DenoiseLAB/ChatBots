TypeHandler
===========

.. autoclass:: telegram.ext.TypeHandler
    :members:
    :show-inheritance:
