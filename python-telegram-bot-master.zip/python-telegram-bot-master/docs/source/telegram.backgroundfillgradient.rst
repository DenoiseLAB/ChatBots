BackgroundFillGradient
======================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundFillGradient
    :members:
    :show-inheritance: