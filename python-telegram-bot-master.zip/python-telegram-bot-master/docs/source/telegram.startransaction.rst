StarTransaction
===============

.. autoclass:: telegram.StarTransaction
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
