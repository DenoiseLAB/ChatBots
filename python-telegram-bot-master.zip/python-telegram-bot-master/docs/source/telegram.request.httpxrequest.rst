HTTPXRequest
============

.. autoclass:: telegram.request.HTTPXRequest
    :members:
    :show-inheritance: