telegram package
================

Version Constants
-----------------

.. automodule:: telegram
   :members: __version__, __version_info__, __bot_api_version__, __bot_api_version_info__

Classes in this package
-----------------------

.. toctree::
    :titlesonly:

    telegram.bot
    telegram.at-tree.rst
    telegram.stickers-tree.rst
    telegram.inline-tree.rst
    telegram.payments-tree.rst
    telegram.games-tree.rst
    telegram.passport-tree.rst

