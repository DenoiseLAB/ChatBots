InputPollOption
===============

.. autoclass:: telegram.InputPollOption
    :members:
    :show-inheritance:
