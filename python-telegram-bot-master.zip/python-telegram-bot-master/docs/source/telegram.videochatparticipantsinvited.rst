VideoChatParticipantsInvited
============================

.. autoclass:: telegram.VideoChatParticipantsInvited
    :members:
    :show-inheritance:

