ChatBackground
==============

.. versionadded:: 21.2

.. autoclass:: telegram.ChatBackground
    :members:
    :show-inheritance: