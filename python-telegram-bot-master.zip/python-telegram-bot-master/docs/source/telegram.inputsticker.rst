InputSticker
============

.. autoclass:: telegram.InputSticker
    :members:
    :show-inheritance:
