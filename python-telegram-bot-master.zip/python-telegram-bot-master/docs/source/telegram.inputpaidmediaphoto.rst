InputPaidMediaPhoto
===================

.. autoclass:: telegram.InputPaidMediaPhoto
    :members:
    :show-inheritance: