telegram.error Module
=====================

.. automodule:: telegram.error
    :members:
    :show-inheritance:
