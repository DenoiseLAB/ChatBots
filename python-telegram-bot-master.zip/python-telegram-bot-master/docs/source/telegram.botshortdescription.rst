BotShortDescription
===================

.. autoclass:: telegram.BotShortDescription
    :members:
    :show-inheritance: