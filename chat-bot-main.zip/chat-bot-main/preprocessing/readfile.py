import string

# Функция для очистки текста
def preprocess_text(text):
    # Преобразуем в нижний регистр и удаляем пунктуацию
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text

# Загружаем диалоги персонажа из файла
def load_lines_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    lines = [preprocess_text(line.strip()) for line in lines]
    return lines
