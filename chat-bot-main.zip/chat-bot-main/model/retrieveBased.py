import numpy as np
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from preprocessing.readfile import preprocess_text

vectorizer = TfidfVectorizer(stop_words="english")

class Model:
    def __init__(self, replics):
        # Private field (indicated by single underscore)
        self._replics = replics
        self._matrix = vectorizer.fit_transform(replics)

    def retrieve_response(self, query):
        preprocessed_query = preprocess_text(query)
        query_vector = vectorizer.transform([preprocessed_query])

        # Вычисление сходства
        cosine_similarities = cosine_similarity(query_vector, self._matrix)

        # Найдём наиболее похожую реплику
        most_similar_idx = cosine_similarities.argmax()
        response = self._replics[most_similar_idx]
        similarity_score = cosine_similarities[0][most_similar_idx]
        return self._replicss[most_similar_idx], cosine_similarities[0][most_similar_idx], cosine_similarities[0]