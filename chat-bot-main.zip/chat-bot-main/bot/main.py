from flask import Flask, jsonify, request

from model.retrieveBased import Model
from preprocessing.readfile import load_lines_from_file

app = Flask(__name__)
replics = load_lines_from_file('../data/Scherlock_1.txt')
bot = Model(replics)

@app.route('/ask', methods=['POST'])
def hello():
    data = request.get_json()
    question = data.get('question', '')
    if question == '':
        return jsonify({"error": "Bad Request", "message": "the question can't be empty"}), 400
    result = bot.retrieve_response(question)
    return jsonify({"response": result})

if __name__ == '__main__':
    app.run(debug=True)